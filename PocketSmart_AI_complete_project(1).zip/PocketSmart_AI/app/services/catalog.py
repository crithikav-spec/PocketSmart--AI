from urllib.parse import quote

PLATFORM_DOMAINS = {
    "Amazon": "https://www.amazon.in/s?k=",
    "Flipkart": "https://www.flipkart.com/search?q=",
    "IKEA": "https://www.ikea.com/in/en/search/?q=",
    "Swiggy": "https://www.swiggy.com/search?query=",
    "Zomato": "https://www.zomato.com/search?q=",
    "OYO": "https://www.oyorooms.com/search?q=",
}

HOME_ITEMS = [
    ("LED Ceiling Light", "Lighting", "Amazon", 1299),
    ("Minimalist Floor Lamp", "Lighting", "IKEA", 2499),
    ("Compact Dining Table", "Furniture", "IKEA", 7999),
    ("Ergonomic Study Chair", "Furniture", "Amazon", 5499),
    ("Wall Art Set", "Decor", "Amazon", 1799),
    ("Storage Cabinet", "Furniture", "Flipkart", 6499),
    ("Ceiling Fan", "Appliances", "Amazon", 2899),
    ("Decorative Indoor Plant", "Decor", "IKEA", 899),
]

PARTY_ITEMS = [
    ("Buffet Catering Package", "Catering", "Swiggy", 450),
    ("Party Meal Package", "Catering", "Zomato", 500),
    ("Birthday Decoration Package", "Decoration", "Amazon", 2499),
    ("Event Lighting Package", "Decoration", "Amazon", 3499),
    ("Budget Event Venue", "Venue", "OYO", 9000),
    ("Premium Event Venue", "Venue", "OYO", 15000),
]

JEWELRY_ITEMS = [
    ("Pearl Drop Earrings", "Earrings", "Amazon", 1499),
    ("Minimal Gold-Tone Necklace", "Necklace", "Flipkart", 2299),
    ("Statement Kundan Set", "Set", "Amazon", 3999),
    ("Silver-Tone Bracelet", "Bracelet", "Flipkart", 1799),
    ("Crystal Pendant", "Pendant", "Amazon", 1299),
]

def search_catalog(planner: str, budget: float, query: str = "") -> list[dict]:
    source = {
        "home": HOME_ITEMS,
        "party": PARTY_ITEMS,
        "jewelry": JEWELRY_ITEMS,
    }[planner]

    items = []
    for name, category, platform, price in source:
        if price <= budget * 0.8 or budget < 3000:
            items.append({
                "name": name,
                "category": category,
                "platform": platform,
                "price": price,
                "currency": "INR",
                "source": "simulated_catalog",
                "url": PLATFORM_DOMAINS[platform] + quote(name),
            })
    return items[:8]
