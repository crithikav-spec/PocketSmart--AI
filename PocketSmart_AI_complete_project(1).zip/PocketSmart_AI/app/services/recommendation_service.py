from typing import Any, Optional
from .catalog import search_catalog
from .gemini_service import gemini_service

HOME_PROMPT = """You are PocketSmart AI's home interior budget planner.
Create a practical plan that respects the user's total budget. Allocate spending by room/category,
then select suitable products from the supplied simulated catalog. Avoid claiming live inventory or
live prices. Prefer value, functionality, and the requested style."""
PARTY_PROMPT = """You are PocketSmart AI's party budget planner.
Allocate the user's budget across venue, catering, decoration, and entertainment. Consider guest
count and event type. Use the supplied simulated catalog. Do not claim live vendor availability."""
JEWELRY_PROMPT = """You are PocketSmart AI's jewelry stylist and budget planner.
Recommend jewelry matching occasion, style, outfit color and notes. If an image is supplied, use it
only for visual styling guidance. Stay within budget and use the supplied simulated catalog."""

def _fallback(planner: str, payload: dict[str, Any], catalog: list[dict]) -> dict:
    budget = float(payload["budget"])
    if planner == "home":
        rooms = payload.get("rooms", [])
        allocations = {
            room: round(budget / max(len(rooms), 1), 2) for room in rooms
        }
        summary = f"Budget plan for {len(rooms)} room(s), focused on {payload.get('style', 'Modern')} style."
    elif planner == "party":
        guests = payload["guests"]
        allocations = {
            "venue": round(budget * 0.25, 2),
            "catering": round(budget * 0.45, 2),
            "decoration": round(budget * 0.20, 2),
            "entertainment": round(budget * 0.10, 2),
        }
        summary = f"Plan for {guests} guests for a {payload['event_type']}."
    else:
        allocations = {
            "jewelry": round(budget * 0.85, 2),
            "accessories": round(budget * 0.15, 2),
        }
        summary = f"{payload['style']} jewelry suggestions for {payload['occasion']}."

    recs = [x for x in catalog if x["price"] <= budget]
    return {
        "summary": summary,
        "allocations": allocations,
        "recommendations": recs,
    }

def build_recommendation(
    planner: str,
    payload: dict[str, Any],
    image_bytes: Optional[bytes] = None,
    mime_type: Optional[str] = None,
) -> dict[str, Any]:
    catalog = search_catalog(planner, float(payload["budget"]))
    prompt = {"home": HOME_PROMPT, "party": PARTY_PROMPT, "jewelry": JEWELRY_PROMPT}[planner]

    ai = gemini_service.generate_json(
        prompt + f"\nCandidate catalog:\n{catalog}",
        payload,
        image_bytes=image_bytes,
        mime_type=mime_type,
    )

    if ai and isinstance(ai, dict):
        return {
            "summary": ai.get("summary", "AI-generated recommendation plan."),
            "allocations": ai.get("allocations", {}),
            "recommendations": ai.get("recommendations", catalog),
            "ai_generated": True,
        }

    fallback = _fallback(planner, payload, catalog)
    return {**fallback, "ai_generated": False}
