import json
import os
from typing import Any, Optional

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None
    types = None

class GeminiService:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        self.enabled = os.getenv("AI_ENABLED", "true").lower() == "true"
        self.client = None
        if self.enabled and self.api_key and genai:
            self.client = genai.Client(api_key=self.api_key)

    @property
    def available(self) -> bool:
        return self.client is not None

    def generate_json(
        self,
        system_prompt: str,
        payload: dict[str, Any],
        image_bytes: Optional[bytes] = None,
        mime_type: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        if not self.available:
            return None

        prompt = (
            f"{system_prompt}\n\n"
            "Return ONLY valid JSON. Do not use markdown fences.\n"
            f"User data:\n{json.dumps(payload, ensure_ascii=False)}"
        )

        parts = [prompt]
        if image_bytes and types:
            parts.append(types.Part.from_bytes(data=image_bytes, mime_type=mime_type or "image/jpeg"))

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=parts,
                config=types.GenerateContentConfig(
                    temperature=0.4,
                    response_mime_type="application/json",
                ),
            )
            text = getattr(response, "text", None)
            if not text:
                return None
            return json.loads(text)
        except Exception:
            return None

gemini_service = GeminiService()
