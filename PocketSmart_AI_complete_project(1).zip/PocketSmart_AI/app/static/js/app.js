async function api(url, options={}) {
  const res = await fetch(url, {credentials:"same-origin", ...options});
  const data = await res.json().catch(()=>({detail:"Unexpected server response"}));
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

async function logout(){
  await api("/logout",{method:"POST"});
  location.href="/";
}

function showError(err){
  const el=document.querySelector("#message");
  if(el) el.textContent=err.message;
}

document.addEventListener("DOMContentLoaded",()=>{
  const register=document.querySelector("#registerForm");
  if(register) register.addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(register);
    try{
      await api("/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(fd))});
      location.href="/login";
    }catch(err){showError(err)}
  });

  const login=document.querySelector("#loginForm");
  if(login) login.addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(login);
    try{
      await api("/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(fd))});
      location.href="/dashboard";
    }catch(err){showError(err)}
  });

  const home=document.querySelector("#homeForm");
  if(home) home.addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(home);
    let quantities={};
    if(fd.get("quantities")) { try{quantities=JSON.parse(fd.get("quantities"))}catch{alert("Quantities must be valid JSON") ; return;} }
    try{
      const data=await api("/generate-home",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        budget:Number(fd.get("budget")), rooms:fd.get("rooms").split(",").map(x=>x.trim()).filter(Boolean),
        style:fd.get("style"), quantities
      })});
      renderResult(data);
    }catch(err){renderError(err)}
  });

  const party=document.querySelector("#partyForm");
  if(party) party.addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(party);
    try{
      const data=await api("/generate-party",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        budget:Number(fd.get("budget")), guests:Number(fd.get("guests")),
        event_type:fd.get("event_type"), venue:fd.get("venue"), city:fd.get("city")
      })});
      renderResult(data);
    }catch(err){renderError(err)}
  });

  const jewelry=document.querySelector("#jewelryForm");
  if(jewelry) jewelry.addEventListener("submit",async e=>{
    e.preventDefault();
    try{
      const data=await api("/generate-jewelry",{method:"POST",body:new FormData(jewelry)});
      renderResult(data);
    }catch(err){renderError(err)}
  });

  loadHistory();
});

function renderResult(data){
  const root=document.querySelector("#result");
  if(!root)return;
  const recs=(data.recommendations||[]).map(r=>`
    <div class="recommendation">
      <div><strong>${escapeHtml(r.name||"Recommendation")}</strong> <span class="pill">${escapeHtml(r.platform||"")}</span></div>
      <div class="muted">${escapeHtml(r.category||"")}</div>
      <div class="price">₹${Number(r.price||0).toLocaleString("en-IN")}</div>
      ${r.url?`<a href="${r.url}" target="_blank" rel="noopener">Open platform search</a>`:""}
    </div>`).join("");
  const allocations=Object.entries(data.allocations||{}).map(([k,v])=>`<span class="pill">${escapeHtml(k)}: ₹${Number(v).toLocaleString("en-IN")}</span>`).join("");
  root.innerHTML=`<div class="result-card"><h2>Your plan</h2><p>${escapeHtml(data.summary||"")}</p><p>${allocations}</p><p class="muted">${data.ai_generated?"Generated with Gemini":"Using built-in fallback recommendations"}</p>${recs||"<p>No catalog matches were found.</p>"}</div>`;
}

function renderError(err){const root=document.querySelector("#result"); if(root)root.innerHTML=`<div class="result-card"><p class="message">${escapeHtml(err.message)}</p></div>`}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

async function loadHistory(){
  const box=document.querySelector("#historyList")||document.querySelector("#dashboardHistory");
  if(!box)return;
  try{
    const items=await api("/history");
    if(!items.length){box.innerHTML='<p class="muted">No saved recommendations yet.</p>';return}
    box.innerHTML=items.map(x=>`<div class="history-item"><strong>#${x.id} · ${escapeHtml(x.planner_type)}</strong><div class="muted">${escapeHtml(x.created_at)}</div><div>${escapeHtml(x.result.summary||"")}</div></div>`).join("");
  }catch(err){box.innerHTML=`<p class="message">${escapeHtml(err.message)}</p>`}
}
