from fastapi import APIRouter, Depends, Form, HTTPException, Request, Response
from fastapi.responses import RedirectResponse
from ..database import get_db
from ..schemas import LoginRequest, RegisterRequest
from ..security import create_access_token, hash_password, verify_password, decode_token

router = APIRouter()

def get_current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        return None
    payload = decode_token(token)
    if not payload:
        return None
    with get_db() as db:
        row = db.execute("SELECT id, name, email FROM users WHERE id=?", (int(payload["sub"]),)).fetchone()
    return dict(row) if row else None

def require_user(request: Request):
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user

@router.post("/register")
def register_api(data: RegisterRequest):
    email = data.email.strip().lower()
    with get_db() as db:
        exists = db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
        if exists:
            raise HTTPException(status_code=409, detail="Email already registered")
        cur = db.execute(
            "INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
            (data.name.strip(), email, hash_password(data.password)),
        )
        user_id = cur.lastrowid
    return {"message": "Registration successful", "user_id": user_id}

@router.post("/login")
def login_api(data: LoginRequest, response: Response):
    email = data.email.strip().lower()
    with get_db() as db:
        row = db.execute("SELECT id,name,email,password_hash FROM users WHERE email=?", (email,)).fetchone()
    if not row or not verify_password(data.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token(row["id"], row["email"])
    response.set_cookie("access_token", token, httponly=True, samesite="lax", secure=False, max_age=86400)
    return {"message": "Login successful", "user": {"id": row["id"], "name": row["name"], "email": row["email"]}}

@router.post("/token")
def token_api(data: LoginRequest):
    email = data.email.strip().lower()
    with get_db() as db:
        row = db.execute("SELECT id,email,password_hash FROM users WHERE email=?", (email,)).fetchone()
    if not row or not verify_password(data.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return {"access_token": create_access_token(row["id"], row["email"]), "token_type": "bearer"}

@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("access_token")
    return {"message": "Logged out"}

@router.get("/session-info")
def session_info(request: Request):
    user = get_current_user(request)
    return {"authenticated": bool(user), "user": user}

@router.get("/session-data")
def session_data(request: Request):
    user = require_user(request)
    with get_db() as db:
        count = db.execute(
            "SELECT COUNT(*) AS count FROM recommendations WHERE user_id=?", (user["id"],)
        ).fetchone()["count"]
    return {"user": user, "recommendation_count": count}
