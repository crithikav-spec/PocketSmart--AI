import json
from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile
from ..database import get_db
from ..schemas import HomeRequest, PartyRequest
from ..services.recommendation_service import build_recommendation
from .auth import require_user

router = APIRouter()
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)
ALLOWED_IMAGES = {"image/jpeg", "image/png", "image/webp"}
MAX_IMAGE_BYTES = 5 * 1024 * 1024

def save_history(user_id: int, planner: str, payload: dict, result: dict):
    with get_db() as db:
        cur = db.execute(
            "INSERT INTO recommendations(user_id,planner_type,input_json,result_json) VALUES(?,?,?,?)",
            (user_id, planner, json.dumps(payload), json.dumps(result)),
        )
        return cur.lastrowid

@router.post("/generate-home")
def generate_home(data: HomeRequest, request: Request):
    user = require_user(request)
    result = build_recommendation("home", data.model_dump())
    rid = save_history(user["id"], "home", data.model_dump(), result)
    return {"id": rid, "planner_type": "home", "budget": data.budget, **result}

@router.post("/generate-party")
def generate_party(data: PartyRequest, request: Request):
    user = require_user(request)
    result = build_recommendation("party", data.model_dump())
    rid = save_history(user["id"], "party", data.model_dump(), result)
    return {"id": rid, "planner_type": "party", "budget": data.budget, **result}

@router.post("/generate-jewelry")
async def generate_jewelry(
    request: Request,
    budget: float = Form(...),
    occasion: str = Form(...),
    style: str = Form("Elegant"),
    outfit_color: str = Form(""),
    notes: str = Form(""),
    outfit_image: UploadFile | None = File(None),
):
    user = require_user(request)
    if budget <= 0:
        raise HTTPException(status_code=422, detail="Budget must be positive")

    image_bytes = None
    mime = None
    if outfit_image and outfit_image.filename:
        if outfit_image.content_type not in ALLOWED_IMAGES:
            raise HTTPException(status_code=400, detail="Only JPG, PNG, or WEBP images are supported")
        image_bytes = await outfit_image.read()
        if len(image_bytes) > MAX_IMAGE_BYTES:
            raise HTTPException(status_code=413, detail="Image must be 5 MB or smaller")
        image_path = UPLOAD_DIR / f"{uuid4().hex}{Path(outfit_image.filename).suffix.lower()}"
        image_path.write_bytes(image_bytes)
        mime = outfit_image.content_type

    payload = {
        "budget": budget,
        "occasion": occasion,
        "style": style,
        "outfit_color": outfit_color or None,
        "notes": notes or None,
    }
    result = build_recommendation("jewelry", payload, image_bytes, mime)
    rid = save_history(user["id"], "jewelry", payload, result)
    return {"id": rid, "planner_type": "jewelry", "budget": budget, **result}

@router.get("/recommendations-details/{recommendation_id}")
def recommendation_details(recommendation_id: int, request: Request):
    user = require_user(request)
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM recommendations WHERE id=? AND user_id=?",
            (recommendation_id, user["id"]),
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    return {
        "id": row["id"],
        "planner_type": row["planner_type"],
        "input": json.loads(row["input_json"]),
        "result": json.loads(row["result_json"]),
        "created_at": row["created_at"],
    }

@router.get("/history")
def history(request: Request):
    user = require_user(request)
    with get_db() as db:
        rows = db.execute(
            """SELECT id, planner_type, input_json, result_json, created_at
               FROM recommendations WHERE user_id=? ORDER BY id DESC LIMIT 50""",
            (user["id"],),
        ).fetchall()
    return [
        {
            "id": r["id"],
            "planner_type": r["planner_type"],
            "input": json.loads(r["input_json"]),
            "result": json.loads(r["result_json"]),
            "created_at": r["created_at"],
        }
        for r in rows
    ]
