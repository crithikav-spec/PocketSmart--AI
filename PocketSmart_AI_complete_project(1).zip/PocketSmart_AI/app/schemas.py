from typing import Any, Literal, Optional
from pydantic import BaseModel, Field, field_validator

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: str = Field(min_length=5, max_length=160)
    password: str = Field(min_length=6, max_length=128)

class LoginRequest(BaseModel):
    email: str
    password: str

class HomeRequest(BaseModel):
    budget: float = Field(gt=0)
    rooms: list[str] = Field(min_length=1)
    style: str = Field(default="Modern", max_length=80)
    quantities: dict[str, int] = {}

class PartyRequest(BaseModel):
    budget: float = Field(gt=0)
    guests: int = Field(gt=0, le=10000)
    event_type: str = Field(min_length=2, max_length=80)
    venue: str = Field(default="Flexible", max_length=120)
    city: str = Field(default="India", max_length=100)

class JewelryRequest(BaseModel):
    budget: float = Field(gt=0)
    occasion: str = Field(min_length=2, max_length=80)
    style: str = Field(default="Elegant", max_length=80)
    outfit_color: Optional[str] = Field(default=None, max_length=80)
    notes: Optional[str] = Field(default=None, max_length=1000)

class RecommendationResponse(BaseModel):
    id: int
    planner_type: str
    budget: float
    summary: str
    allocations: dict[str, Any]
    recommendations: list[dict[str, Any]]
    ai_generated: bool
    created_at: str
