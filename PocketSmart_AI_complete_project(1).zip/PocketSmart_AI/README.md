# PocketSmart AI

PocketSmart AI is a FastAPI + Jinja2 application based on the supplied project documentation. It provides:

- Home Interior Budget Planner
- Party Budget Planner
- Jewelry Budget Planner with optional outfit image
- Registration/login/logout and JWT-based API authentication
- Recommendation history
- SQLite persistence
- Gemini multimodal integration
- Deterministic fallback/mock catalog when Gemini is unavailable
- Responsive HTML/CSS/JavaScript frontend

## Important implementation note

The source document names Gemini 1.5 Flash Pro and several commercial platforms. Those model/API names and third-party APIs can change. This implementation keeps the model configurable through `GEMINI_MODEL` and uses the current `google-genai` SDK. The catalog layer is deliberately a mock/simulated sourcing layer rather than scraping Amazon, Flipkart, IKEA, Swiggy, Zomato, or OYO.

## 1. VS Code setup

1. Open this folder in VS Code.
2. Create a Python 3.11+ virtual environment:

### Windows PowerShell
```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
```

### macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Copy `.env.example` to `.env`.
5. Put your Gemini API key in `GEMINI_API_KEY`.
6. Start the application:
```bash
uvicorn app.main:app --reload
```
7. Open http://127.0.0.1:8000

## 2. If Gemini is not configured

The application still works. Set:
```env
AI_ENABLED=false
```
or leave the API key blank. The planner endpoints will use the built-in deterministic recommendation engine.

## 3. Test

Run:
```bash
pytest -q
```

Manual API docs:
http://127.0.0.1:8000/docs

## 4. Project structure

```text
PocketSmart_AI/
├── app/
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── security.py
│   ├── routes/
│   │   ├── auth.py
│   │   ├── pages.py
│   │   └── planners.py
│   ├── services/
│   │   ├── catalog.py
│   │   ├── gemini_service.py
│   │   └── recommendation_service.py
│   ├── static/
│   │   ├── css/style.css
│   │   └── js/app.js
│   └── templates/
│       ├── base.html
│       ├── index.html
│       ├── login.html
│       ├── register.html
│       ├── dashboard.html
│       ├── planner.html
│       └── history.html
├── data/
├── tests/
├── .env.example
├── requirements.txt
└── README.md
```

## 5. API endpoints

- `POST /register`
- `POST /login`
- `POST /logout`
- `POST /token`
- `GET /session-info`
- `GET /session-data`
- `POST /generate-home`
- `POST /generate-party`
- `POST /generate-jewelry`
- `GET /recommendations-details/{id}`
- `GET /history`
- `POST /startup`

The browser UI uses cookie-based JWT sessions. The `/token` endpoint also returns a bearer token for API clients.

## 6. Security

- Passwords are salted and hashed with PBKDF2-HMAC-SHA256.
- JWTs are signed using the configured `SECRET_KEY`.
- Uploaded outfit images are size-limited and stored with generated filenames.
- User recommendation history is scoped to the authenticated user.
- Never commit `.env` or a real API key.
