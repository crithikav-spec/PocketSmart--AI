import os
os.environ["DATABASE_URL"] = "sqlite:///./data/test.db"
os.environ["SECRET_KEY"] = "test-secret"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").json()["status"] == "ok"

def test_register_login_and_session():
    email = "test@example.com"
    r = client.post("/register", json={"name":"Test User","email":email,"password":"secret123"})
    assert r.status_code in (200, 409)

    r = client.post("/login", json={"email":email,"password":"secret123"})
    assert r.status_code == 200
    assert client.get("/session-info").json()["authenticated"] is True

def test_home_requires_auth():
    r = client.post("/generate-home", json={"budget":10000,"rooms":["Bedroom"],"style":"Modern","quantities":{}})
    assert r.status_code == 401
